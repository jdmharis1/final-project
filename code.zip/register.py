import dashboard
import tkinter as tk
from functools import partial
import random
from utils import load_data, write_data
from tkinter.messagebox import showinfo

def registration_window():
	'''
	This is called when the user clicks on the "Register" button in
	the login window. This function creates a which asks for the user information and
	then if the user is new then adds the user to the users list.
	'''
	user_dict = load_data() # Load the current user data
	def register(user_dict, username, password, balance):
		'''
		This function is called whenever the puser presses the "Register"
		button within the registration page window.

		Inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		username (tkinter string object):		This tkinter string object 
												stores the data written 
												in the username field.

		password (tkinter string object):		This tkinter string object 
												stores the data written 
												in the password field.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.
		'''
		user = username.get()
		user_pass = password.get()
		bal = balance.get()

		if len(user_pass) == 0 or len(user) == 0:
			showinfo("Error", "Username and password cannot be empty")

		if user not in user_dict:
			user_dict[user] = {}
			user_dict[user]["password"] = user_pass
			user_dict[user]["balance"] = bal
			write_data(user_dict)
			
			tkWindow.destroy()
			dashboard.dashboard(username, password, bal)

		else:
			showinfo("Error", "Username already exists")

	def exit_app():
		'''
		This function exits the application
		'''
		tkWindow.destroy()

	# A window is created
	tkWindow = tk.Tk()
	tkWindow.geometry('400x250')  
	tkWindow.title('Register')

	# Create username and password fields
	username_label = tk.Label(tkWindow, text="Username").grid(row=0, column=0)
	username = tk.StringVar()
	usernameEntry = tk.Entry(tkWindow, textvariable=username).grid(row=0, column=1)

	balance = tk.StringVar()
	balance.set("100")

	password_label = tk.Label(tkWindow,text="Password").grid(row=5, column=0)   
	password = tk.StringVar()
	password_entry = tk.Entry(tkWindow, textvariable=password, show='*').grid(row=5, column=1)

	# Callback to registration function and registration button
	register = partial(register, user_dict, username, password, balance)

	register_button = tk.Button(tkWindow, text="Register", command=register).grid(row=8, column=0) 
	exitButton = tk.Button(tkWindow, text="Exit", command=exit_app).grid(row=9, column=0)

	tkWindow.mainloop()

if __name__ == "__main__":
	registration_window()