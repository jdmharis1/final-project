import os
import thankyou
import tkinter as tk
from functools import partial
from PIL import ImageTk, Image
from utils import load_data, write_data
from tkinter.messagebox import showinfo

def dashboard(username, password, balance):
	'''
	This is the main dashboard of the program. The dashboard window
	opens whenever the user logs in successfully or creates a new account
	successfully.
	'''
	user_dict = load_data() # This is where all the current userdata is extracted

	def purchaseWash(user_dict, balance):
		'''
		This is where the user buys a wash and the amount is deducted from the account.

		inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.

		outputs:
		None
		'''
		if int(balance.get()) < 20 :
			showinfo("Error", "You Don't have enough balance to purchase this item. Add balance please.")
		else:
			print("Wash Purchased")
			balance.set(int(balance.get()) - 20)
			user_dict[username.get()]["balance"] = str(int(user_dict[username.get()]["balance"]) - 20)

	def carSteam(user_dict, balance):
		'''
		This is where the user buys a car steaming and the amount is deducted from the account.

		inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.

		outputs:
		None
		'''
		if int(balance.get()) < 20 :
			showinfo("Error", "You Don't have enough balance to purchase this item. Add balance please.")
		else:
			print("Car Steam Purchased")
			balance.set(int(balance.get()) - 20)
			user_dict[username.get()]["balance"] = str(int(user_dict[username.get()]["balance"]) - 20)

	def cleaning(user_dict, balance):
		'''
		This is where the user buys a car cleaning and the amount is deducted from the account.

		inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.

		outputs:
		None
		'''
		if int(balance.get()) < 20 :
			showinfo("Error", "You Don't have enough balance to purchase this item. Add balance please.")
		else:
			print("Cleaning Purchased")
			balance.set(int(balance.get()) - 20)
			user_dict[username.get()]["balance"] = str(int(user_dict[username.get()]["balance"]) - 20)

	def carDetailing(user_dict, balance):
		'''
		This is where the user buys a car detailing and the amount is deducted from the account.

		inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.

		outputs:
		None
		'''
		if int(balance.get()) < 20 :
			showinfo("Error", "You Don't have enough balance to purchase this item. Add balance please.")
		else:
			print("Car Detailing Purchased")
			balance.set(int(balance.get()) - 20)
			user_dict[username.get()]["balance"] = str(int(user_dict[username.get()]["balance"]) - 20)

	def internalCleaning(user_dict, balance):
		'''
		This is where the user buys a car internal cleaning and the amount is deducted from the account.

		inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.

		outputs:
		None
		'''
		if int(balance.get()) < 20 :
			showinfo("Error", "You Don't have enough balance to purchase this item. Add balance please.")
		else:
			print("Car Internal Cleaning Purchased")
			balance.set(int(balance.get()) - 20)
			user_dict[username.get()]["balance"] = str(int(user_dict[username.get()]["balance"]) - 20)

	def addBalance(user_dict, balanceToAdd, balance):
		'''
		If the user runs out of balance, they can add more to their account. The balance
		amount needs to be typed in the balance field and then added to the current balance.

		Inputs:

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.

		balanceToAdd (tkinter string object):	This tkinter string object 
												stores the data written 
												in the balance to add field.


		balance (tkinter string object):		This tkinter string object 
												stores the starting balance 
												in the account.
		'''
		if not balanceToAdd.get().isdigit() or int(balanceToAdd.get()) <= 0 :
			showinfo("Error", "Invalid Balance Value. Balance must be a positive integer value.")
		
		else:
			balance.set(str(int(balance.get()) + int(balanceToAdd.get())))
			user_dict[username.get()]["balance"] = balance.get()

	def logout(user_dict):
		'''
		This function logs the user out of the application and shows a thank you window.

		user_dict (Dictionary):					This dictionary contains 
												the username and password 
												combinations for the accounts.
		'''
		write_data(user_dict)
		tkWindow.destroy()
		thankyou.thankyou()

	def exit_app():
		'''
		This function exits the application
		'''
		tkWindow.destroy()

	# A window is created
	tkWindow = tk.Tk()
	tkWindow.geometry('310x650')  
	tkWindow.title('User Dashboard')

	# Create image frame
	img_frame = tk.Frame(tkWindow)
	img_frame.grid(row=0, column=0, padx=5, pady=5, sticky='nesw') 

	# If image exits place the image otherwise write an alternate text in its place
	if os.path.exists("img1.jpg"):
		img = ImageTk.PhotoImage(Image.open("img1.jpg").resize((306, 245), Image.ANTIALIAS))
		panel = tk.Label(img_frame, image = img)
		panel.grid(row=0, column=0)

	else:
		tk.Label(img_frame, text="Car wash image.").grid(row=0, column=0)

	# Create user info frame
	info_frame = tk.Frame(tkWindow)
	info_frame.grid(row=1, column=0, padx=5, pady=5, sticky='nesw') 

	# populate user Info
	tk.Label(info_frame, text="Username").grid(row=1, column=0)
	tk.Label(info_frame, text=username.get()).grid(row=1, column=1)

	balance_str = tk.StringVar()
	balance_str.set(balance)
	tk.Label(info_frame, text="Balance").grid(row=7, column=0)
	tk.Label(info_frame, textvariable=balance_str).grid(row=7, column=1)
	
	# Add button frame
	button_frame = tk.Frame(tkWindow)
	button_frame.grid(row=2, column=0, padx=5, pady=5, sticky='nesw') 
	
	# Create buttons for every single available service and also add their callbacks
	purchaseWash = partial(purchaseWash, user_dict, balance_str)
	tk.Button(button_frame, text="Purchase Wash", command=purchaseWash).grid(row=2, column=0, padx=5, pady=5, sticky='nesw') 
	tk.Label(button_frame, text="$20").grid(row=2, column=1)
	
	carSteam = partial(carSteam, user_dict, balance_str)
	tk.Button(button_frame, text="Car Steam", command=carSteam).grid(row=3, column=0, padx=5, pady=5, sticky='nesw') 
	tk.Label(button_frame, text="$20").grid(row=3, column=1)

	cleaning = partial(cleaning, user_dict, balance_str)
	tk.Button(button_frame, text="Cleaning", command=cleaning).grid(row=4, column=0, padx=5, pady=5, sticky='nesw') 
	tk.Label(button_frame, text="$20").grid(row=4, column=1)

	carDetailing = partial(carDetailing, user_dict, balance_str)
	tk.Button(button_frame, text="Car Detailing", command=carDetailing).grid(row=5, column=0, padx=5, pady=5, sticky='nesw') 
	tk.Label(button_frame, text="$20").grid(row=5, column=1)

	internalCleaning = partial(internalCleaning, user_dict, balance_str)
	tk.Button(button_frame, text="Interior Cleaning", command=internalCleaning).grid(row=6, column=0, padx=5, pady=5, sticky='nesw') 
	tk.Label(button_frame, text="$20").grid(row=6, column=1)

	# Create balance to add field
	balanceToAdd = tk.StringVar()
	balanceToAdd.set('0')
	tk.Entry(button_frame, textvariable=balanceToAdd).grid(row=7, column=1)

	# Add button to call back to balance adding function
	addBalance = partial(addBalance, user_dict, balanceToAdd, balance_str)
	tk.Button(button_frame, text="Add Balance ($)", command=addBalance).grid(row=7, column=0, padx=5, pady=5, sticky='nesw') 

	# Logout button
	logout = partial(logout, user_dict)
	tk.Button(button_frame, text="Logout", command=logout).grid(row=8, column=0, padx=5, pady=5, sticky='nesw') 

	# Exit button
	exitButton = tk.Button(tkWindow, text="Exit", command=exit_app).grid(row=9, column=0)

	tkWindow.mainloop()

if __name__ == "__main__":
	dashboard()