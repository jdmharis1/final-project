import os
import login
import tkinter as tk
from functools import partial
from PIL import ImageTk, Image
from utils import load_data, write_data
from tkinter.messagebox import showinfo

def thankyou():
	'''
	This function creates a window that shows the thank you message and allows the user to redirect to
	login page.
	'''
	def login_again():
		'''
		This function exits the thank you page and goes to the login page again.
		'''
		tkWindow.destroy()
		login.init_login()

	def exit_app():
		'''
		This function exits the application
		'''
		tkWindow.destroy()

	# A window is created
	tkWindow = tk.Tk()
	tkWindow.geometry("315x350")  
	tkWindow.title("Thank You")

	# A frame is created where an image is placed.
	img_frame = tk.Frame(tkWindow)
	img_frame.grid(row=0, column=0, padx=5, pady=5, sticky='nesw') 
	if os.path.exists("img2.jpeg"): # If the image exists place that image otherwise simple put an alternate label in its place

		img = ImageTk.PhotoImage(Image.open("img2.jpeg").resize((306, 245), Image.ANTIALIAS))
		panel = tk.Label(img_frame, image = img)
		panel.grid(row=0, column=0)
	else:
		tk.Label(img_frame, text="Thumbs up image.").grid(row=0, column=0)

	# Label with text
	tk.Label(img_frame, text="Thank you choosing us. Visit us again soon.").grid(row=1, column=0)

	# Login button
	tk.Button(tkWindow, text="Login", command=login_again).grid(row=1, column=0, padx=5, pady=5, sticky='nesw') 

	# Exit button
	exitButton = tk.Button(tkWindow, text="Exit", command=exit_app).grid(row=2, column=0)

	tkWindow.mainloop()