def load_data():
	'''
	This function reads the data from the file that contains the username
	and password combinations.
	'''
	try:
		inFile = open("user_data.txt", "r")
	except:
		inFile = open("user_data.txt", "w")
		inFile.close()
		inFile = open("user_data.txt", "r")
	
	allLines = inFile.readlines()
	user_dict = {}
	
	for line in allLines:
		line = line.replace("\n","")
		line = line.split(",")
		user = line[0]
		user_pass = line[1]
		user_bal = line[2]

		user_dict[user] = {}
		user_dict[user]["password"] = user_pass
		user_dict[user]["balance"] = user_bal

	inFile.close()

	return user_dict

def write_data(user_dict):
	'''
	This function writes the login data of a new user to a txt file.
	user_dict (Dictionary):					This dictionary contains 
											the username and password 
											combinations for the accounts.
	'''
	outFile = open("user_data.txt", "w")
	for user in user_dict:
		line = user+","+user_dict[user]["password"]+","+user_dict[user]["balance"]
		outFile.write(line + "\n")
	outFile.close()