import tkinter as tk
from functools import partial
import register
import dashboard
from utils import load_data, write_data
from tkinter.messagebox import showinfo



def init_login():
	'''
	This is the main login function that opens the login window.
	'''
	def check_login(username, password, user_dict):
		'''
		This function validates login by a user. The functions 
		takes the username, password and a dictionary containing 
		username and password combos.
		
		Inputs:

		username (tkinter string object): 	This tkinter string object 
											stores the data written 
											in the username field.

		password (tkinter string object): 	This tkinter string object 
											stores the data written 
											in the password field.

		user_dict (Dictionary): 			This dictionary contains 
											the username and password 
											combinations for the accounts.

		
		Output:
		
		None
		'''

		# Get username and passwrod form tkinter strings
		user = username.get() 
		user_pass = password.get()

		if len(user)==0 or len(user_pass) == 0:
			showinfo("Error", "Username and password cannot be empty")
		
		if user in user_dict:
			if user_dict[user]["password"] == user_pass:
				balance = user_dict[user]["balance"]
				tkWindow.destroy()
		
				dashboard.dashboard(username, password, balance)
	
			else:
				showinfo("Error", "Username or password invalid")
		else:
			showinfo("Error", "Username or password invalid")

	def register_user():
		'''
		This function exits the current login window and creates a new window
		where the user can register a new account.
		'''
		tkWindow.destroy()
		register.registration_window()

	def exit_app():
		'''
		This function exits the application
		'''
		tkWindow.destroy()

	usernameDict = load_data()
	tkWindow = tk.Tk()   # Create the window for login
	tkWindow.geometry('400x150')  
	tkWindow.title('Login')

	# Create appropriate label that shows the information on the login screen
	usernameLabel = tk.Label(tkWindow, text="Username").grid(row=0, column=0)
	username = tk.StringVar() # Variable to store the username
	usernameEntry = tk.Entry(tkWindow, textvariable=username).grid(row=0, column=1)   # Entry box where the username will be typed

	# The label for the password is placed on the screen
	passwordLabel = tk.Label(tkWindow,text="Password").grid(row=1, column=0)   
	password = tk.StringVar() # The variable that will store the password
	passwordEntry = tk.Entry(tkWindow, textvariable=password, show='*').grid(row=1, column=1)  # This entry box is where the user types the password

	check_login = partial(check_login, username, password, usernameDict) # The login validation function is passed through the partial function specifying which variables will be passed to the function

	loginButton = tk.Button(tkWindow, text="Login", command=check_login).grid(row=4, column=0)   # The login button will callback to the validation function
	registerButton = tk.Button(tkWindow, text="Register", command=register_user).grid(row=4, column=1)

	exitButton = tk.Button(tkWindow, text="Exit", command=exit_app).grid(row=5, column=0)

	tkWindow.mainloop()

if __name__ == "__main__":
	init_login()